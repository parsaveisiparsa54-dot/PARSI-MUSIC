package com.djparsi.parsimusic

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.*
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.*

private data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : Activity() {
    private val tracks = mutableListOf<Track>()
    private var player: MediaPlayer? = null
    private var visualizer: Visualizer? = null
    private var current = -1
    private var blue = false
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var playButton: Button
    private lateinit var scene: ImageView
    private lateinit var meter: DjEqualizerView
    private lateinit var themeButton: Button
    private lateinit var stageTitle: TextView
    private val accent get() = if (blue) Color.rgb(35, 105, 255) else Color.rgb(255, 35, 45)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        blue = getPreferences(0).getBoolean("blue_theme", false)
        buildUi()
        requestAudioAccess()
    }

    private fun requestAudioAccess() {
        val needed = mutableListOf<String>()
        val read = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, read) != PackageManager.PERMISSION_GRANTED) needed.add(read)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 10) else scanMusic()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) scanMusic()
            else Toast.makeText(this, "برای نمایش آهنگ‌های گوشی، اجازه دسترسی به موسیقی لازم است.", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 12, 18, 18); setBackgroundColor(Color.rgb(5,5,7)) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val logo = ImageView(this).apply { setImageResource(R.drawable.parsi_logo); scaleType = ImageView.ScaleType.FIT_CENTER }
        header.addView(logo, LinearLayout.LayoutParams(76, 54))
        val brand = TextView(this).apply { text = "PARSI MUSIC"; textSize = 19f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-black", Typeface.BOLD); letterSpacing = .12f }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val theme = Button(this).apply { text = if (blue) "BLUE" else "RED"; setOnClickListener { blue = !blue; getPreferences(0).edit().putBoolean("blue_theme", blue).apply(); applyTheme() } }
        header.addView(theme)
        root.addView(header)

        val stageTitle = TextView(this).apply { text = "DJ STAGE  •  ${if (blue) "BLUE MODE" else "RED MODE"}"; textSize = 12f; letterSpacing = .18f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 14, 0, 8) }
        root.addView(stageTitle)
        scene = ImageView(this).apply { setImageResource(if (blue) R.drawable.dj_scene_blue else R.drawable.dj_scene_red); scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.BLACK, 22) ; clipToOutline = true }
        root.addView(scene, LinearLayout.LayoutParams(-1, 250))

        val eqLabel = TextView(this).apply { text = "DJ PARSI  •  LIVE AUDIO EQUALIZER"; textSize = 11f; letterSpacing = .12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0, 12, 0, 2) }
        root.addView(eqLabel)
        meter = DjEqualizerView(this).apply { setAccent(accent) }
        root.addView(meter, LinearLayout.LayoutParams(-1, 86))

        nowTitle = TextView(this).apply { text = "No track selected"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(0, 8, 0, 2) }
        nowArtist = TextView(this).apply { text = "Scan your device library"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY) }
        root.addView(nowTitle); root.addView(nowArtist)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
        val prev = controlButton("⏮") { playAt((current - 1).coerceAtLeast(0)) }
        playButton = controlButton("▶") { togglePlayback() }
        val next = controlButton("⏭") { playAt((current + 1).coerceAtMost(tracks.lastIndex)) }
        controls.addView(prev); controls.addView(playButton); controls.addView(next); root.addView(controls)

        val libraryHead = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val libraryTitle = TextView(this).apply { text = "ON DEVICE MUSIC"; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; letterSpacing = .1f }
        libraryHead.addView(libraryTitle, LinearLayout.LayoutParams(0, -2, 1f))
        libraryHead.addView(Button(this).apply { text = "RESCAN"; setOnClickListener { scanMusic() } })
        root.addView(libraryHead)
        val scroller = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(list)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        applyTheme()
    }

    private fun controlButton(label: String, action: () -> Unit): Button = Button(this).apply { text = label; textSize = 19f; setTextColor(Color.WHITE); background = rounded(Color.rgb(28,28,34), 40); setOnClickListener { action() }; val p = LinearLayout.LayoutParams(64, 52); p.setMargins(8,0,8,0); layoutParams = p }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat(); setStroke(1, accent) }

    private fun applyTheme() {
        if (!::root.isInitialized) return
        val color = accent
        themeButton.text = if (blue) "BLUE" else "RED"
        stageTitle.text = "DJ STAGE  •  ${if (blue) "BLUE MODE" else "RED MODE"}"
        scene.setImageResource(if (blue) R.drawable.dj_scene_blue else R.drawable.dj_scene_red)
        meter.setAccent(color)
        window.statusBarColor = Color.rgb(5,5,7)
        window.navigationBarColor = Color.rgb(5,5,7)
        // Accent is applied to the stage frame and interactive controls.
        scene.background = rounded(Color.BLACK, 22)
    }

    private fun scanMusic() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")
            cursor?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    tracks.add(Track(id, c.getString(titleCol) ?: "Unknown track", c.getString(artistCol) ?: "Unknown artist", uri))
                }
            }
        } catch (_: Exception) { Toast.makeText(this, "اسکن موسیقی انجام نشد.", Toast.LENGTH_SHORT).show() }
        renderTracks()
        if (tracks.isEmpty()) Toast.makeText(this, "آهنگ محلی پیدا نشد. فایل صوتی به گوشی اضافه کن و دوباره اسکن کن.", Toast.LENGTH_LONG).show()
    }

    private fun renderTracks() {
        list.removeAllViews()
        tracks.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); background = rounded(Color.rgb(17,17,21), 14); setOnClickListener { playAt(index) } }
            val title = TextView(this).apply { text = track.title; textSize = 14f; setTextColor(Color.WHITE); maxLines = 1 }
            val artist = TextView(this).apply { text = track.artist; textSize = 11f; setTextColor(Color.LTGRAY); maxLines = 1 }
            row.addView(title); row.addView(artist)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 5, 0, 5); list.addView(row, lp)
        }
    }

    private fun playAt(index: Int) {
        if (index !in tracks.indices) return
        releasePlayer()
        current = index
        try {
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, tracks[index].uri)
                setOnPreparedListener { mp -> mp.start(); playButton.text = "Ⅱ"; attachVisualizer(mp.audioSessionId) }
                setOnCompletionListener { if (current < tracks.lastIndex) playAt(current + 1) else { playButton.text = "▶"; meter.setLevel(0f) } }
                prepareAsync()
            }
            nowTitle.text = tracks[index].title
            nowArtist.text = tracks[index].artist
            playButton.text = "…"
        } catch (_: Exception) { Toast.makeText(this, "پخش این فایل ممکن نیست.", Toast.LENGTH_SHORT).show() }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) { if (tracks.isNotEmpty()) playAt(0); return }
        if (p.isPlaying) { p.pause(); playButton.text = "▶"; meter.setLevel(0.08f) }
        else { p.start(); playButton.text = "Ⅱ" }
    }

    private fun attachVisualizer(sessionId: Int) {
        try {
            visualizer?.release()
            visualizer = Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer, waveform: ByteArray, samplingRate: Int) {
                        var sum = 0.0
                        for (b in waveform) { val x = (b.toInt() and 0xff) - 128; sum += x.toDouble() * x }
                        meter.setLevel((sqrt(sum / waveform.size) / 128.0).toFloat().coerceIn(0f,1f))
                    }
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) { }
                }, Visualizer.getMaxCaptureRate() / 2, true, false)
                enabled = true
            }
        } catch (_: Exception) { meter.setLevel(0.15f) }
    }

    private fun releasePlayer() {
        try { visualizer?.enabled = false; visualizer?.release() } catch (_: Exception) { }
        visualizer = null
        try { player?.release() } catch (_: Exception) { }
        player = null
        meter.setLevel(0f)
    }

    override fun onDestroy() { releasePlayer(); super.onDestroy() }
}

private class DjEqualizerView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var level = 0f
    private var accent = Color.RED
    private val bars = FloatArray(44) { 0.08f }
    private val random = java.util.Random()
    fun setAccent(color: Int) { accent = color; invalidate() }
    fun setLevel(value: Float) { level = value.coerceIn(0f,1f); postInvalidateOnAnimation() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val gap = 4f * resources.displayMetrics.density
        val barW = (width - gap * (bars.size - 1)) / bars.size
        val mid = height * .82f
        for (i in bars.indices) {
            val target = if (level < .015f) .045f else (0.08f + level * (0.25f + .7f * abs(sin(i * .37 + System.nanoTime() / 170_000_000.0)))).toFloat()
            bars[i] = bars[i] * .68f + target * .32f
            val h = (height * .78f * bars[i]).coerceAtLeast(3f)
            paint.color = accent
            paint.alpha = 210
            canvas.drawRoundRect(i * (barW + gap), mid - h, i * (barW + gap) + barW, mid, barW / 2, barW / 2, paint)
        }
        paint.color = Color.WHITE; paint.alpha = 155; paint.textSize = 10f * resources.displayMetrics.density; paint.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        val label = "DJ PARSI"
        canvas.drawText(label, width / 2f - paint.measureText(label) / 2f, height - 2f, paint)
        if (level > .01f && isAttachedToWindow) postInvalidateOnAnimation()
    }
}
